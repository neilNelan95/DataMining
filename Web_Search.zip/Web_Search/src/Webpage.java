
public class Webpage {
    
    private static int numWebpages = 0;
    private final int ID;
    
    private final int[] outgoingLinks;
    
    private String title;
    private String contents;
    
    public Webpage(String _title, String _contents, int[] _outgoingLinks){
    
        outgoingLinks = new int[_outgoingLinks.length];
        
        for(int i = 0; i < _outgoingLinks.length; i++)
            outgoingLinks[i] = _outgoingLinks[i];
        
        title = _title;
        contents = _contents;
        
        //Create a new, unique ID for each webpage created
        ID = numWebpages;
        numWebpages++;
        
    }
    
    public void setContents(String _contents){
        
        contents = _contents;
    
    }
    
    public void setTitle(String _title){
        
        title = _title;
    
    }
    
    public String getContents(){
        
        return contents;
    
    }
    
    public String getTitle(){
        
        return title;
    
    }
    
    public int getID(){
        
        return ID;
    
    }
    
    public int[] getLinks(){
        
        return outgoingLinks;
    
    }
    
    public boolean contains(String query){
    
        return title.contains(query) || contents.contains(query);
    
    }
    
    public int numHits(String query){
    
        //Number of hits
        int hitCount = 0;
        
        //Count number of matches in the contents
        if(contents.contains(query)){
            
            for(int i = contents.indexOf(query);        //Initialize with the first matching index.
                    i >= 0;                             //Continue as long as we keep getting matches
                    i = contents.indexOf(query, i+1))   //Find the next match
                
                hitCount++;
            
        }
        
        //Count number of matches in the title
        if(title.contains(query)){
            
            for(int i = title.indexOf(query);           //As above.
                    i >= 0;                             
                    i = title.indexOf(query, i+1))   
                
                hitCount++;
            
        }
        
        return hitCount;
    
    }
    
}