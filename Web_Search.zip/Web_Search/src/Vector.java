//Neil Nelanuthala (700702350)
public class Vector extends Matrix{
    
    public Vector(int height){
        
        super(height, 1);
        
    }
    
    public Vector(int height, double fill){
        
        super(height, 1, fill);
        
    }
    
    public void set(int y, double val){
    
        super.set(y, 0, val);
    
    }
    
    public double get(int y){
    
        return super.get(y, 0);
    
    }
    
}