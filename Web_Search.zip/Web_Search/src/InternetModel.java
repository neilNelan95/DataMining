//Neil Nelanuthala (700702350)
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class InternetModel {
    
    private final Webpage[] webpageArray;
    private final Matrix transitionMatrix;
    
    private InternetModel(int numPages){
    
        webpageArray = new Webpage[numPages];
        transitionMatrix = new Matrix(numPages, numPages); //Matrix is a perfect square based on the number of pages present.
    
    }
    
    public static InternetModel loadFromFile(String filename) throws FileNotFoundException{
        
        Scanner sc = new Scanner(new File(filename));

        //The input file will have the following format:
        //Number of Webpages to load
        //The webpage title in a string on one line
        //The webpage content in a string on one line
        //One line of comma-separated numbers, representing links FROM this webpage to OTHER webpages
        int numPages = Integer.parseInt(sc.nextLine().trim());
        
        //Initialize our web model with the number of pages we've got
        InternetModel model = new InternetModel(numPages);
        
        for(int i = 0; i < numPages; i++){
            
            Webpage page;
            String title, contents;
            
            String[] unparsedLinks;
            int[] outgoingLinks;
            
            //Get all the raw data
            title = sc.nextLine();
            //System.out.println(title);
            
            contents = sc.nextLine();
            //System.out.println(contents);
            
            //Cut up the linked pages into an array
            unparsedLinks = sc.nextLine().trim().split(",");
            
            //Initialize the int array
            outgoingLinks = new int[unparsedLinks.length];
            
            //Convert the strings into ints and stick em into the webpage array
            for(int j = 0; j < unparsedLinks.length; j++){
            
                //System.out.print(s);
                outgoingLinks[j] = Integer.parseInt(unparsedLinks[j].trim());
            
            }
            
            //Initialize the final page
            page = new Webpage(title, contents, outgoingLinks);
            
            //Stick it into the model's webpage array. Guarantees that it is sorted by ID
            model.webpageArray[i] = page;
            
        }
        
        sc.close();
        
        //Generate the transition matrix for this model
        model.generateTransitionMatrix();
        
        return model;
        
    }
    
    private void generateTransitionMatrix(){
    
        //Here we iterate through each page
        for(int x = 0; x < transitionMatrix.getWidth();x++){
            
            double val = 1.0/webpageArray[x].getLinks().length;
            
            for(int link : webpageArray[x].getLinks()){
                
                transitionMatrix.set(link, x, val);
                
            }
            
        }
        
        System.out.println("Page 'vote' matrix for all 25 pages.");
        
        System.out.println("1     2     3     4     5     6     7     8     9     10    11    12    13    14    15    16    17    18    19    20    21    22    23    24    25");
        System.out.println(transitionMatrix);
        
    }
    
    public Vector iteratePageRankWithGuess(Vector initialGuess, int numIterations){
        
        if(initialGuess.getHeight() != transitionMatrix.getWidth())
            throw new IllegalArgumentException("Error, cannot use this initial guess");
        
        Matrix iteratedMatrix = transitionMatrix.pow(numIterations);
        
        Matrix result = iteratedMatrix.mult(initialGuess);
        
        
        return result.toVector();
        
    }
    
    
    
    
    public ArrayList<Webpage> searchQuery(String query, int numResults){
        
        if(numResults <= 0)
            throw new IllegalArgumentException("Cannot have zero or less results");
        
        //Returns "numResults" number of webpages which have the query
        ArrayList<Webpage> rtn = new ArrayList();
        
        //Generate pagerank values. 10 iterations with an initual guess vector of 1 should be good enough.
        Vector pageRankVals = iteratePageRankWithGuess(new Vector(webpageArray.length, 1), 10).toVector();
        
        for(Webpage w : webpageArray){
        
            //This page contains the search query. 
            if(w.contains(query))
            {
            
                if(rtn.isEmpty())
                    rtn.add(w);
                else{
                    
                    int i = 0;
                    
                    //Inserts the page in the correct place in the return arraylist
                    while(i < rtn.size() && pageRankVals.get(w.getID()) < pageRankVals.get(rtn.get(i).getID()))
                        i++;
                        
                    rtn.add(i, w);
                    
                }
            
            }
        
        }
        
        while(rtn.size() > numResults)
            rtn.remove(numResults);
        
        return rtn;
        
    }
        
    public int getNumPages(){
    
        return webpageArray.length;
    
    }
    
}