//Neil Nelanuthala (700702350)
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.ArrayList;

public class Client {
    
    public static void main(String[] args){
    	
    	Scanner input = new Scanner(System.in);
        
        try{
        
            //Generate out model from the input file
            InternetModel model = InternetModel.loadFromFile("input.txt");
            
            //Create a guess vector to model the pagerank values with
            //Has height equal to the number of pages, with default value of 1
            Vector guess = new Vector(model.getNumPages(), 1);
            
            System.out.println("\nInitial Pagerank vector.\n");
            System.out.println(model.iteratePageRankWithGuess(guess, 1));
            
            System.out.println("\nPagerank vector after 5 iterations.\n");
            System.out.println(model.iteratePageRankWithGuess(guess, 5));
            
            System.out.println("\nPagerank vector after 10 iterations.\n");
            System.out.println(model.iteratePageRankWithGuess(guess, 10));
            
            System.out.println("\nPagerank vector after 15 iterations.\n");
            System.out.println(model.iteratePageRankWithGuess(guess, 15));
            
            System.out.println("\nPagerank vector after 20 iterations.\n");
            System.out.println(model.iteratePageRankWithGuess(guess, 20));
            
            //Now we do a search query.
            System.out.println("Enter a query (name of a fruit): ");
            
            String query = input.next();
            
            //Create an arraylist to hold each page that comes in with the results
            ArrayList<Webpage> results = model.searchQuery(query, 15);
            
            //Print how many results were returned (should be equal to or less than whats passed in searchQuery
            if (results.size() > 0) System.out.println("Here are the " + results.size() + " most relevant pages.");
            else System.out.println("No relevant pages.");
            for(Webpage w : results){
            
                //Print the title of every page that came in with the results
                System.out.println(w.getTitle());
            
            }
            
        }catch(FileNotFoundException e){
            
            System.out.println(e.getMessage());
            
        }
        
    }
}
    