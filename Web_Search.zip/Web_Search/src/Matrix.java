//Neil Nelanuthala (700702350)
import java.util.LinkedList;

public class Matrix {
    
    private final int height, width;
    private final LinkedList<LinkedList<Double>> matrix;
   
    //Initializes an empty integer matrix
    public Matrix(int _height, int _width){
    
        this(_height, _width, 0);
        
    }
    
    public Matrix(int _height, int _width, double fill){
        
        height = _height;
        width = _width;
    
        matrix = new LinkedList();
        
        //Initialize the matrix
        LinkedList temp;
        for(int i = 0; i < height; i++){
            
            temp = new LinkedList();
            
            for(int j = 0; j < width; j++)
                temp.add(fill);
            
            matrix.add(temp);
            
        }
        
    }
    
    public int getWidth(){
        
        return width;
    
    }
    public int getHeight(){
        
        return height;
    
    }
    
    public double get(int y, int x){
        
        return matrix.get(y).get(x);
        
    }
    
    public void set(int y, int x, double val){
    
        if(x < 0 || x >= width || y < 0 || y >= height)
            throw new IndexOutOfBoundsException();
    
        matrix.get(y).remove(x);
        matrix.get(y).add(x, val);
        
    }
    
    public Matrix mult(Matrix other) {
        
        if(this.width != other.height)
            throw new IllegalArgumentException("Dimension mismatch: These arrays cannot be multiplied together (" + height + ", " + width + ") x (" + other.height + ", " + other.width + ")");
        
        Matrix rtn = new Matrix(height, other.width);
        
        for(int y = 0; y < height; y++){
            
            for(int x = 0; x < other.width; x++){
                
                double val = 0;
                for(int i = 0; i < other.height; i++){
                
                    double thisVal = this.get(y, i);
                    double otherVal = other.get(i, x);
                    
                    val += thisVal * otherVal;
                    
                }
                
                rtn.set(y, x, val);
                
            }
        
        }
        
        return rtn;
    
    }
    
    
    public Matrix minus(Matrix other) {
        
        if(this.width != other.height)
            throw new IllegalArgumentException("Dimension mismatch: These arrays cannot be multiplied together (" + height + ", " + width + ") x (" + other.height + ", " + other.width + ")");
        
        Matrix rtn = new Matrix(height, other.width);
        
        for(int y = 0; y < height; y++){
            
            for(int x = 0; x < other.width; x++){
                
                double val = 0;
                for(int i = 0; i < other.height; i++){
                
                    double thisVal = this.get(y, i);
                    double otherVal = other.get(i, x);
                    
                    val += thisVal - otherVal;
                    
                }
                
                rtn.set(y, x, val);
                
            }
        
        }
        
        return rtn;
    
    }
    
    
    public static Matrix getIdentity(int size){
    
        Matrix rtn = new Matrix(size, size);
        
        for(int i = 0; i < size; i++)
                rtn.set(i, i, 1);
    
        return rtn;
        
    }
    
    public Matrix copy(){
    
        //If it is square, we can just multiply by the identity
        if(this.height == this.width)
            return this.mult(getIdentity(height));
    
        //Otherwise make a new matrix and copy all the values
        Matrix rtn = new Matrix(height, width);
        
        for(int x = 0; x < width; x++)
            for(int y = 0; y < height; y++)
                rtn.set(y, x, this.get(x, y));
        
        return rtn;
        
    }
    
    //Raises a matrix to a certain power. Works only for square matrices.
    public Matrix pow(int power){
        
        if(this.height != this.width)
            throw new IllegalArgumentException("Non-square matrices may not be multiplied by themselves");
        else if(power <= 0)
            throw new IllegalArgumentException("Invalid power given");
        
        Matrix rtn = this.copy();
        
        //Multiply this matrix by the original, and save it
        for(int i = 1; i < power; i++)
            rtn = this.mult(rtn);
        
        return rtn;
        
    }
    
    //Checks if two matrices are identical
    public boolean equals(Matrix other){
    
        if(this.height != other.height || this.width != other.width)
            return false;
        
        for(int x = 0; x < this.width; x++)
            for(int y = 0; y < this.height; y++)
            {
            
                if(this.get(x, y) != other.get(x, y))
                    return false;
            
            }
                
                
        return true;
        
    
    }
    
    //Converts this matrix into a vector, if possible. Otherwise throw an exception
    public Vector toVector(){
        
        if(this.width != 1)
            throw new IllegalArgumentException("This matrix cannot be converted to a vector");
        
        Vector rtn = new Vector(this.height);
        for(int i = 0; i < this.height; i++)
            rtn.set(i, this.get(i, 0));
        
        return rtn;
        
    }
    
    static int precision = 3;
    static void setPrecision(int _precision){precision = _precision;}
    
    //Gives a nice string representation for a matrix
    @Override
    public String toString(){
    
        String rtn = "";
        
        for(int i = 0; i < height; i++){
            
            for(int j = 0; j < width; j++){
                
                rtn += String.format("%." + precision + "f ", matrix.get(i).get(j));
                
            }
            
            rtn += "\n";
            
        }
        
        return rtn;
    
    }
    
}