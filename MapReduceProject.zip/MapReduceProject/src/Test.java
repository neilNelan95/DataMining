//Neil Nelanuthala (700702350)
//12.19.2017
import java.io.File;


public class Test {
    public static void main(String[]args){
    	System.out.println("Example input file from Star Wars ep. III \n");
        Mapper fileMapper = new Mapper(new File("darthPlagueis.txt"));
        fileMapper.readFile();
        System.out.println("MAPPER: Below is the list of raw, word counts from the given input file.");
        System.out.println();
        System.out.println(fileMapper);
        Reducer mapReducer = new Reducer(fileMapper);
        mapReducer.reduce();
        System.out.println();
        System.out.println("REDUCER: Below is the list of (k,v) pairs after the fileMapper has been reduced.\n");
        System.out.println(mapReducer.toString());
        System.out.println();
        DataManager dataManager = new DataManager(mapReducer.reducedMap);
        dataManager.sort(mapReducer.reducedMap);
        System.out.println();
        System.out.println("SORT: Below is the sorted list of (k,v) pairs descending by number of instances. \n");
        dataManager.sort(mapReducer.reducedMap);
    }
}
