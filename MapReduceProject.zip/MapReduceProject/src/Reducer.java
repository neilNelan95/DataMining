//Neil Nelanuthala (700702350)
//12.19.2017
import java.util.ArrayList;
import java.util.HashMap;


public class Reducer {
    Mapper mapper;
    HashMap<String,Integer> reducedMap;
    public Reducer(Mapper mapper){
        reducedMap = new HashMap<String,Integer>();
        this.mapper = mapper;
    }

    public void reduce(){
        ArrayList<HashMap<String,Integer>> hashedLines = mapper.getlinesHashedFromFile();
        for(int i = 0; i < hashedLines.size();++i){

            for (int j = 0; j < hashedLines.get(i).size();++j){

                String key = (String) hashedLines.get(i).keySet().toArray()[j];
                Integer value = (Integer) hashedLines.get(i).values().toArray()[j];

                if (reducedMap.containsKey(hashedLines.get(i).keySet().toArray()[j])){
                    Integer prev = reducedMap.get(key).intValue();
                    reducedMap.remove(key);//.keySet().toArray()[j]);
                    reducedMap.put(key,  value + prev );
                }else{
                    reducedMap.put((String)hashedLines.get(i).keySet().toArray()[j],1);
                }

            }

        }
    }

    public void setMapper(Mapper mapper) {
        this.mapper = mapper;
    }

    public HashMap<String, Integer> getReducedHashMap() {
        return this.reducedMap;
    }

    public void setReducedHashMap(HashMap<String, Integer> reducedMap) {
        this.reducedMap = reducedMap;
    }

    public String toString(){
        return reducedMap.toString();
    }

}
