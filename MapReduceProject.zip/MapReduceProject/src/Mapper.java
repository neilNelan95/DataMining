//Neil Nelanuthala (700702350)
//12.19.2017
import java.io.*;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;



public class Mapper {
    private ArrayList<HashMap<String,Integer>> linesHashedFromFile;
    private File inputFile;
    private String lineString;

    public Mapper(File inputFile){
        linesHashedFromFile = new ArrayList<HashMap<String, Integer>>();
        this.inputFile = inputFile;
    }

    public void readFile(){
        try {
            FileReader myFileReader = new FileReader(inputFile);
            BufferedReader myBufferReader = new BufferedReader(myFileReader);

            while((lineString = myBufferReader.readLine())!= null){
                linesHashedFromFile.add(mapLine(lineString));
            }

            myBufferReader.close();
            myFileReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("\nFile was not found.");
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    public HashMap<String,Integer> mapLine(String lineString){
        HashMap<String, Integer> map = new HashMap<String, Integer>();
        lineString = lineString.replaceAll(","," ");
        lineString = lineString.replaceAll("\n"," ");
        String[] words = lineString.split(" ");
        for (int i = 0; i < words.length; ++i){
            map.put(words[i],1);
        }
        return map;
    }

    public ArrayList<HashMap<String, Integer>> getlinesHashedFromFile() {
        return this.linesHashedFromFile;
    }

    public String toString(){
        String s = "";
        for (int i = 0; i < linesHashedFromFile.size(); ++i){
            for(int j = 0; j <linesHashedFromFile.get(i).size();++j) {
                s+=  "("+ ((Map.Entry<String, Integer>)linesHashedFromFile.get(i).entrySet().toArray()[j]).getKey()+", "+((Map.Entry<String, Integer>)linesHashedFromFile.get(i).entrySet().toArray()[j]).getValue()+"), ";
                if (j%5 == 0) s+= "\n";
            }
        }
                return s;
    }
}























