//Neil Nelanuthala (700702350)
//12.19.2017
import java.util.*;
import java.util.Map.Entry;


public class DataManager {
    private HashMap<String,Integer> sortedValues;

    public DataManager(HashMap<String,Integer> reducedMapOfValues){
        this.sortedValues = reducedMapOfValues;
    }


    public HashMap<String, Integer> sort(HashMap<String,Integer> reducedMapOfValues) {

        Object[] array = reducedMapOfValues.entrySet().toArray();
        Arrays.sort(array, new Comparator() {
        public int compare(Object o1, Object o2) {
              return ((Entry<String, Integer>) o2).getValue().compareTo(((Entry<String, Integer>) o1).getValue());
            }
        });
        for (Object obj : array) {
            System.out.println(((Entry<String, Integer>) obj).getKey() + " : " + ((Entry<String, Integer>) obj).getValue()); 
            
        }
            return reducedMapOfValues;
    }
}
